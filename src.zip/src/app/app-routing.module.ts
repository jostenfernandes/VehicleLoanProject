import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { LoginComponent } from './login/login.component';
import { NewregiformComponent } from './Registration/newregiform/newregiform.component';
import { ShowregiformComponent } from './Registration/showregiform/showregiform.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ApplyLoanPageComponent } from './apply-loan-page/apply-loan-page.component';
import { CheckeligibiltyComponent } from './checkeligibilty/checkeligibilty.component';
import { EmicalculatorComponent } from './emicalculator/emicalculator.component';
import { AddDetailsComponent } from './PersonalDetails/add-details/add-details.component';
import { ShowDetailsComponent } from './PersonalDetails/show-details/show-details.component';
import { AddEmployeeComponent } from './EmploymentDetails/add-employee/add-employee.component';
import { AddLoanDetailsComponent } from './LoanDetails/add-loan-details/add-loan-details.component';
import { ShowLoanDetailsComponent } from './LoanDetails/show-loan-details/show-loan-details.component';
import { AddVehicleDetailsComponent } from './VehicleDetails/add-vehicle-details/add-vehicle-details.component';
import { ShowVehicleDetailsComponent } from './VehicleDetails/show-vehicle-details/show-vehicle-details.component';
import { UserdashboardComponent } from './userdashboard/userdashboard.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { ShowEmployeeComponent } from './EmploymentDetails/show-employee/show-employee.component';
import { LoanofferPageComponent } from './loanoffer-page/loanoffer-page.component';


const routes: Routes = [
  {path: '', component: HomepageComponent},
  {path: 'aboutus', component: AboutUsComponent},
  {path: 'login', component: LoginComponent},
  {path: 'newregistration', component: NewregiformComponent},
  {path: 'addform', component: NewregiformComponent},
  {path: 'showallforms', component: ShowregiformComponent},
  {path: 'login', component: LoginComponent},
  {path: 'adminlogin', component: AdminloginComponent},
  {path: 'applyloan', component: ApplyLoanPageComponent},
  {path: 'checkeligibility', component: CheckeligibiltyComponent},
  {path: 'calculator', component: EmicalculatorComponent},
  {path: 'addPersonalDetails', component: AddDetailsComponent},
  {path: 'showPersonalDetails', component: ShowDetailsComponent},
  {path: 'addEmployeeDetails', component: AddEmployeeComponent},
  {path: 'showEmployeeDetails', component: ShowEmployeeComponent},
  {path: 'addLoanDetails', component: AddLoanDetailsComponent },
  {path: 'showLoanDetails', component: ShowLoanDetailsComponent},
  {path: 'addVehicleDetails', component: AddVehicleDetailsComponent},
  {path: 'showVehicleDetails', component: ShowVehicleDetailsComponent},
  {path: 'userdashboard', component: UserdashboardComponent},
  {path: 'admindashboard', component: AdmindashboardComponent},
  {path: 'loanoffer', component: LoanofferPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
