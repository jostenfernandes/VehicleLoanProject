import { Regiform } from './regiform';

describe('Regiform', () => {
  it('should create an instance', () => {
    expect(new Regiform()).toBeTruthy();
  });
});
