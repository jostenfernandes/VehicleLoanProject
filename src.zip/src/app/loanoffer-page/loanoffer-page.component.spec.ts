import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanofferPageComponent } from './loanoffer-page.component';

describe('LoanofferPageComponent', () => {
  let component: LoanofferPageComponent;
  let fixture: ComponentFixture<LoanofferPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanofferPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanofferPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
