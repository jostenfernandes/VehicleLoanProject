import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loanoffer-page',
  templateUrl: './loanoffer-page.component.html',
  styleUrls: ['./loanoffer-page.component.css']
})
export class LoanofferPageComponent implements OnInit {

  optionValue:any;
  schemeValue:any;

  constructor() { }

  ngOnInit(): void {
  }

}
