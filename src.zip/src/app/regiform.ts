export class Regiform 
{
    registerId:number|undefined;
    password:string|undefined;
    firstName:string|undefined;
    lastName:string|undefined;
    email:string|undefined;
    gender:string|undefined;
    mobileNo:number|undefined;
    dob:Date|undefined;
    age:number|undefined;
    address:string|undefined;
    city:string|undefined;
    state:string|undefined;
    pinCode:number|undefined;
}
