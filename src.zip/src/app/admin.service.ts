import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private myhttp:HttpClient) { }

  restUrl:string="http://localhost:9092/rest/api";

  searchbyID(srchText:any)
  {
    return this.myhttp.get(this.restUrl+"/loan/"+srchText);
  }

  searcbyEmail(srchText:any)
  {
    return this.myhttp.get(this.restUrl+"/searchuser/"+srchText)
  }

  searchByLoanId(srchText:any)
  {
    return this.myhttp.get(this.restUrl+"/searchloan/"+srchText)
  }
}
