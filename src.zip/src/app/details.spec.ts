import { Details } from './details';

describe('Details', () => {
  it('should create an instance', () => {
    expect(new Details()).toBeTruthy();
  });
});
