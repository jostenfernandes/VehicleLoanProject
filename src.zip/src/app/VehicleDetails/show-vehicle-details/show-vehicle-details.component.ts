import { Component, OnInit } from '@angular/core';
import { DetailsService } from 'src/app/details.service';

@Component({
  selector: 'app-show-vehicle-details',
  templateUrl: './show-vehicle-details.component.html',
  styleUrls: ['./show-vehicle-details.component.css']
})
export class ShowVehicleDetailsComponent implements OnInit {

  constructor(private vhs:DetailsService) { }
  vehicleList:any;

  ngOnInit(): void 
  {
    this.vhs.getAllVehicleDetails().subscribe(
      (data)=>{
        console.log(data);
        this.vehicleList = data;
      },
      (error)=>
      {
        console.log(error);
      }
    )
  }

}
