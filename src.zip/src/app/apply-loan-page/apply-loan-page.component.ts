import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-loan-page',
  templateUrl: './apply-loan-page.component.html',
  styleUrls: ['./apply-loan-page.component.css']
})
export class ApplyLoanPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
