import { Component, OnInit } from '@angular/core';
import { DetailsService } from 'src/app/details.service';

@Component({
  selector: 'app-show-details',
  templateUrl: './show-details.component.html',
  styleUrls: ['./show-details.component.css']
})
export class ShowDetailsComponent implements OnInit {

  constructor(private vhs:DetailsService) { }
  personalList:any;

  ngOnInit(): void 
  {
    this.vhs.getAllDetails().subscribe(
      (data)=>{
        console.log(data);
        this.personalList = data;
      },
      (error)=>
      {
        console.log(error);
      }
    )
  }

}
