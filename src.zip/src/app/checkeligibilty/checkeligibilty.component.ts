import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-checkeligibilty',
  templateUrl: './checkeligibilty.component.html',
  styleUrls: ['./checkeligibilty.component.css']
})
export class CheckeligibiltyComponent implements OnInit {

  constructor(private myrouter: Router) { }

  ngOnInit(): void {
  }

  checkEligibility(item:any)
  {
    console.warn(item);
    alert("You are Eligible fill your application form...!")
    this.myrouter.navigate(['\loanoffer']);
  }

}
