import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckeligibiltyComponent } from './checkeligibilty.component';

describe('CheckeligibiltyComponent', () => {
  let component: CheckeligibiltyComponent;
  let fixture: ComponentFixture<CheckeligibiltyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckeligibiltyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckeligibiltyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
