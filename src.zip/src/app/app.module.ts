import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule} from '@angular/forms';
import { CommonModule } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomepageComponent } from './homepage/homepage.component';
import { FooterComponent } from './footer/footer.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { LoginComponent } from './login/login.component';
import { NewregiformComponent } from './Registration/newregiform/newregiform.component';
import { ShowregiformComponent } from './Registration/showregiform/showregiform.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ApplyLoanPageComponent } from './apply-loan-page/apply-loan-page.component';
import { CheckeligibiltyComponent } from './checkeligibilty/checkeligibilty.component';
import { EmicalculatorComponent } from './emicalculator/emicalculator.component';
import { AddDetailsComponent } from './PersonalDetails/add-details/add-details.component';
import { ShowDetailsComponent } from './PersonalDetails/show-details/show-details.component';
import { AddEmployeeComponent } from './EmploymentDetails/add-employee/add-employee.component';
import { ShowEmployeeComponent } from './EmploymentDetails/show-employee/show-employee.component';
import { AddLoanDetailsComponent } from './LoanDetails/add-loan-details/add-loan-details.component';
import { ShowLoanDetailsComponent } from './LoanDetails/show-loan-details/show-loan-details.component';
import { GetLoanByIdComponent } from './LoanDetails/get-loan-by-id/get-loan-by-id.component';
import { AddVehicleDetailsComponent } from './VehicleDetails/add-vehicle-details/add-vehicle-details.component';
import { ShowVehicleDetailsComponent } from './VehicleDetails/show-vehicle-details/show-vehicle-details.component';
import { UserdashboardComponent } from './userdashboard/userdashboard.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { CheckeligibilitycalComponent } from './checkeligibilitycal/checkeligibilitycal.component';
import { LoanofferPageComponent } from './loanoffer-page/loanoffer-page.component';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomepageComponent,
    FooterComponent,
    AboutUsComponent,
    LoginComponent,
    NewregiformComponent,
    ShowregiformComponent,
    AdminloginComponent,
    ApplyLoanPageComponent,
    CheckeligibiltyComponent,
    EmicalculatorComponent,
    AddDetailsComponent,
    ShowDetailsComponent,
    AddEmployeeComponent,
    ShowEmployeeComponent,
    AddLoanDetailsComponent,
    ShowLoanDetailsComponent,
    GetLoanByIdComponent,
    AddVehicleDetailsComponent,
    ShowVehicleDetailsComponent,
    UserdashboardComponent,
    AdmindashboardComponent,
    CheckeligibilitycalComponent,
    LoanofferPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
