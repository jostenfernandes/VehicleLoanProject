import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckeligibilitycalComponent } from './checkeligibilitycal.component';

describe('CheckeligibilitycalComponent', () => {
  let component: CheckeligibilitycalComponent;
  let fixture: ComponentFixture<CheckeligibilitycalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckeligibilitycalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckeligibilitycalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
