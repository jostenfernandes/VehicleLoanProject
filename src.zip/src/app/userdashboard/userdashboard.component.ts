import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent implements OnInit {

  srchText:any;
  userList:any;

  constructor(private phs:AdminService) { }

  ngOnInit(): void {
  }

  search()
  {
    this.phs.searcbyEmail(this.srchText).subscribe(
      (data)=>{
        console.log(data);
        this.userList=data;
      }
    )
  }

}
