import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetLoanByIdComponent } from './get-loan-by-id.component';

describe('GetLoanByIdComponent', () => {
  let component: GetLoanByIdComponent;
  let fixture: ComponentFixture<GetLoanByIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetLoanByIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetLoanByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
