import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/admin.service';

@Component({
  selector: 'app-get-loan-by-id',
  templateUrl: './get-loan-by-id.component.html',
  styleUrls: ['./get-loan-by-id.component.css']
})
export class GetLoanByIdComponent implements OnInit {

  constructor(private vhs:AdminService) { }
  srchText:any;
  loanList:any;

  ngOnInit(): void 
  {
  }

  search()
  {
    this.vhs.searchByLoanId(this.srchText).subscribe(
      (data)=>{
        console.log(data);
        this.loanList=data;
      }
    )
  }

}
