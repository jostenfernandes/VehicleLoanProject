import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admindashboard',
  templateUrl: './admindashboard.component.html',
  styleUrls: ['./admindashboard.component.css']
})
export class AdmindashboardComponent implements OnInit {

  srchText:any;
  userList:any;
  show="";

  status="pending";

  constructor(private phs: AdminService) { }

  ngOnInit(): void {
  }

  deleteProduct()
  {
   this.status = "rejected";
  }

  approve()
  {
    this.status = "approved";
    // alert("Application approved");
  }

  pending()
  {
    this.status = "pending";
  }

  showLoan()
  {
    this.show = "<app-show-employee></app-show-employee>";
  }

  search()
  {
    this.phs.searchbyID(this.srchText).subscribe(
      (data)=>{
        console.log(data);
        this.userList=data;
      }
    )
  }

}
